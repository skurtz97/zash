/*	$NetBSD: filecomplete.h,v 1.16 2026/08/15 09:47:27 christos Exp $	*/

/*-
 * Copyright (c) 1997 The NetBSD Foundation, Inc.
 * All rights reserved.
 *
 * This code is derived from software contributed to The NetBSD Foundation
 * by Jaromir Dolecek.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE NETBSD FOUNDATION, INC. AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef _FILECOMPLETE_H_
#define _FILECOMPLETE_H_

int fn_complete(EditLine *,
    char *(*)(const char *, int),
    char **(*)(const char *, int, int),
    const wchar_t *, const wchar_t *, const char *(*)(const char *), size_t,
    int *, int *, int *, int *);
int fn_complete2(EditLine *,
    char *(*)(const char *, int),
    char **(*)(const char *, int, int),
    const wchar_t *, const wchar_t *, const char *(*)(const char *), size_t,
    int *, int *, int *, int *, unsigned int);
#define FN_QUOTE_MATCH 1U		/* Quote the returned match */
#define FN_MATCH_HIDDEN_FILES 2U	/* Match files starting with . */

void fn_display_match_list(EditLine *, char **, size_t, size_t,
	const char *(*)(const char *));
char *fn_tilde_expand(const char *);
char *fn_filename_completion_function(const char *, int);

/* XXX: readline */
char **completion_matches(const char *, char *(*)(const char *, int));

#endif
